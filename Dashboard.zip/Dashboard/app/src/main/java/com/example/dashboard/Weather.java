package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Weather extends AppCompatActivity {

    //Global variables go here for our whole entire activity
    //These will be bound to the XML elements we need to interact with
    TextView txtTemp, txtLocation, txtHumidity, txtPressure,txtTempHigh, txtTempLow;
    Button btnGetWeather, btnBack;
    EditText edtZipCode;
    ImageView imgWeatherIcon;
    CardView cardWeatherData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        //Assign all java variables to correspond with the correct xml element
        txtTemp = findViewById(R.id.txtTemp);
        txtHumidity = findViewById(R.id.txtHumidity);
        txtPressure = findViewById(R.id.txtPressure);
        txtTempHigh = findViewById(R.id.txtTempHigh);
        txtTempLow = findViewById(R.id.txtTempLow);
        imgWeatherIcon = findViewById(R.id.imgWeatherIcon);
        cardWeatherData = findViewById(R.id.cardWeatherData);
        btnGetWeather = findViewById(R.id.btnGetWeather);
        txtLocation = findViewById(R.id.txtLocation);
        edtZipCode = findViewById(R.id.edtZipcode);
        btnBack = findViewById(R.id.weaBtnBack);

        //Turn off the weather card until we get data back from the API
        cardWeatherData.setVisibility(View.INVISIBLE);


        btnGetWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //this code runs when we click the button
                // Anything run in our Weather class is run on the User interface thread.
                //Requests from the internet must be called from a separate thread, to do that we're going to use an async task
                //An async task runs at the same time in the background
                GetFromApi getFromApi = new GetFromApi();
                //When we call .execute that will run onPreExecute -> doInBackground -> onPostExecute
                getFromApi.execute("http://api.openweathermap.org/data/2.5/weather?zip=" + edtZipCode.getText().toString() + ",us&APPID=818a1ff583b7c766dad022e5db640bfd");
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //built into Android, this function ends/closes the current activity
                finish();
            }
        });

    }
    //Create the drop down options menu to send us to other activities
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.navigation_weather, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Define what happens when you click on an item in the options menu
        switch (item.getItemId()) {
            case R.id.menu_news:
                //start the news activity
                Intent intent2 = new Intent(Weather.this,News.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.menu_traffic:
                //start the traffic activity
                Intent intent3 = new Intent(Weather.this,Traffic.class);
                startActivity(intent3);
                finish();
                return true;
            case R.id.menu_exit:
                //exit the entire app
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //AsycnTask<*Input to the doInBackground (which is where we access the internet*, *Input to the onProgressUpdate Function,
    // which we did not use*, *output from the doInBackground() and also the input to onPostExecute()
    private class GetFromApi extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
          //this runs before doInBackground()

        }

        //.execute("url")
        //

        @Override
        protected String doInBackground(String... params) {
            //Do some task

            //params comes in as a string array
            String url = params[0];
            HttpURLConnection con = null ;
            InputStream is = null;

            try {

                con = (HttpURLConnection) ( new URL(url)).openConnection();
                con.setRequestMethod("GET");
                con.setDoInput(true);
                con.setDoOutput(true);
                con.connect();

// Let's read the response
                StringBuffer buffer = null;
                try {
                    buffer = new StringBuffer();
                    is = con.getInputStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    String line = null;
                    while ( (line = br.readLine()) != null )
                        buffer.append(line);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                is.close();
                con.disconnect();
                //buffer is all of the data from the api, in this case it is a string in the format of a JSON object
                return buffer.toString();
            }
            catch(Throwable t) {
                t.printStackTrace();
            }
            finally {
                try { is.close(); } catch(Throwable t) {}
                try { con.disconnect(); } catch(Throwable t) {}
            }
            return null;

            //publishProgress (1);

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //Update the progress of current task
        }

        @Override
        protected void onPostExecute(String result) {
            //Show the result obtained from doInBackground
            //Parse the JSON information returned from the API
            try {
                //Result is a string in the format of a JSON object so create a JSON object from it
                JSONObject jsonResult = new JSONObject(result);
                //Parsing the JSON data based on the keys inside the JSONObject
                //The keys are determined by the API
                JSONObject main = jsonResult.getJSONObject("main");
                //get temperature
                int tempK = main.getInt("temp");
                int tempF = (int) (tempK - 273.15) * 9/5 + 32;
                //Change the textview
                txtTemp.setText(String.valueOf(tempF) + " \u2109");

                //get low temp
                int lowTemp = convertToF(main.getInt("temp_min"));
                txtTempLow.setText(lowTemp + " \u2109");

                //get high temp
                int highTemp = convertToF(main.getInt("temp_max"));
                txtTempHigh.setText(highTemp + " \u2109");

                //get pressure
                int pressure = main.getInt("pressure");
                txtPressure.setText(pressure + " hPa");

                //get humidity
                int humidity = main.getInt("humidity");
                txtHumidity.setText(humidity + " %");

                //Get the location from json object
                String name = jsonResult.getString("name");
                txtLocation.setText(name);

                //get weather image icon identifier
                JSONObject weather = jsonResult.getJSONArray("weather").getJSONObject(0);
                String iconId = null;
                iconId = weather.getString("icon");

                //http://openweathermap.org/img/wn/10d@2x.png
                //Make sure the is data for the icon id before we try to load it into the ImageView
                //using the picasso library
                if (iconId != null){
                    String url = "http://openweathermap.org/img/wn/" + iconId + "@2x.png";
                    //Third Party app that can load an image from a url into an imageview
                     Picasso.get().load(url).into(imgWeatherIcon);
                }

                //Once we have the data make the card visible
                cardWeatherData.setVisibility(View.VISIBLE);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private int convertToF(int input){
            return (int) (input - 273.15) * 9/5 + 32;
        }
    }
}
