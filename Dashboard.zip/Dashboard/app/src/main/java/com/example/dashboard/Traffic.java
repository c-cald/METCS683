package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Traffic extends AppCompatActivity {

    EditText edtAddress1, edtAddress2;
    Button btnGetTravelTime, btnBack;
    TextView txtDistance, txtDuration, txtTime;
    ImageView imgTraffic;

    public static final String API_KEY_MAPS = "AIzaSyA5GcYRBkD1WV3-Zs1A-PKjaMj9X04UiG0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traffic);

        edtAddress1 = findViewById(R.id.edtAddress1);
        edtAddress2 = findViewById(R.id.edtAddress2);
        btnGetTravelTime = findViewById(R.id.btnGetTravelTime);
        txtDistance = findViewById(R.id.txtDistance);
        txtDuration = findViewById(R.id.txtDuration);
        txtTime = findViewById(R.id.txtTime);
        btnBack = findViewById(R.id.trfBtnBack);
        imgTraffic = findViewById(R.id.imgTraffic);


        btnGetTravelTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String startAddress = edtAddress1.getText().toString();
                String endAddress = edtAddress2.getText().toString();

                //check to make sure you have a valid address
                if (startAddress.length() < 1 || endAddress.length() < 1 ){
                    Toast.makeText(Traffic.this, "Please enter a valid address for both inputs", Toast.LENGTH_SHORT).show();
                }else {
                    GetFromApi getFromApi = new GetFromApi();
                    getFromApi.execute("https://maps.googleapis.com/maps/api/directions/json?origin=" +
                            startAddress + "&destination=" + endAddress + "&key=" + API_KEY_MAPS);
                }



            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //built into Android, this function ends/closes the current activity
                finish();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.navigation_traffic, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menu_weather:
                //start the weather activity
                Intent intent = new Intent(Traffic.this,Weather.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.menu_news:
                //start the news activity
                Intent intent2 = new Intent(Traffic.this,News.class);
                startActivity(intent2);
                finish();
                return true;
            case R.id.menu_exit:
                //exit the entire app
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }





    private class GetFromApi extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
            //Setup precondition to execute some task
            //may want to show a progress dialog


        }

        //.execute("url")
        //

        @Override
        protected String doInBackground(String... params) {
            //Do some task

            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            String result = null;
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                //HttpURLConnection.HTTP_
                //int responseCode = connection.getResponseCode();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while (   (line = reader.readLine()   ) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                }
            } catch (Exception e) {
                //Handle the exceptions
                Log.d("Error", "cant get data from internet");
                //showMsg("Error: cant get data from the internet: " + e.getMessage());

            } finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        showMsg("Error closing reader");
                    }
                }
            }
            return result;
            //publishProgress (1);

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //Update the progress of current task
        }

        @Override
        protected void onPostExecute(String result) {
            //Show the result obtained from doInBackground

            if (result != null) {

                try {
                    JSONObject jsonResult = new JSONObject(result);
                    //From debug testing we know that 'routes' is a json array but it only has one item so we want to
                    //extract the json object at index 0
                    //Google  Api Formating is a JSONArray with one JSONObject in it, so combine the steps
                    //and return the only JSONObject in that JSONArray
                    JSONObject routes = jsonResult.getJSONArray("routes").getJSONObject(0);
                    JSONObject legs = routes.getJSONArray("legs").getJSONObject(0);

                    JSONObject distanceJSON = legs.getJSONObject("distance");
                    String distance = distanceJSON.getString("text");
                    JSONObject durationJSON = legs.getJSONObject("duration");
                    String duration = durationJSON.getString("text");

                    String startAddress = legs.getString("start_address");
                    String endAddress = legs.getString("end_address");

                    //set the text of the textviews on the activity
                    txtDistance.setText(distance);
                    txtDuration.setText(duration);
                    //update the search parameters with the actual address returned from the api
                    edtAddress1.setText(startAddress);
                    edtAddress2.setText(endAddress);

                    //get current time of time
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
                    String currentDateandTime = sdf.format(new Date());
                    txtTime.setText(currentDateandTime);

                    //Update traffic image tint based on the duration of the trip
                    //short is green, medium is yellow, long is red

                    //Duration comes back as X mins or X Hours Y minutes
                    //35 mins
                    String durationParts[] = duration.split(" ");
                    //durationParts[0] = "35"
                    //durationParts[1] = "mins
                    float totalMins = 0;
                    if (durationParts.length== 2){
                        totalMins= Float.valueOf(durationParts[0]);
                    }
                    //1 hour 30 mins
                    //durationParts[0] = "1"
                    //durationParts[1] = "hr
                    //durationParts[2] = "35"
                    //durationParts[3] = "mins
                    else if (durationParts.length == 4){
                        if (durationParts[1].contains("day")){
                            //the image is red
                            totalMins = (24 * 60);
                        } else {
                            int hr = Integer.parseInt(durationParts[0]);
                            int mins =  Integer.parseInt(durationParts[2]);
                            totalMins = (hr*60) + mins;
                        }
                    }


                    String distanceParts[] = distance.split(" ");
                    //the distance can have a decimal so round down to nearest integer
                    float temp = Float.valueOf(distanceParts[0]);
                    float floatDistance = (int) temp;
                    float mph = floatDistance /  (totalMins / 60);


                    // reference:
                    if (0 < mph && mph < 25){
                        //tint is red
                        imgTraffic.setColorFilter(Color.RED);
                    } else if (25 <= mph && mph < 50){
                        imgTraffic.setColorFilter(Color.YELLOW);
                    } else {
                        imgTraffic.setColorFilter(Color.GREEN);
                    }


                } catch(JSONException e){
                    e.printStackTrace();
                }



            } else {
                Toast.makeText(Traffic.this, "API parameters did not return any data", Toast.LENGTH_SHORT).show();

            }
        }
    }


    private void showMsg(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
