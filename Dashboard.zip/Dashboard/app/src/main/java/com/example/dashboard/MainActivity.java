package com.example.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Make java variables for our XML elements
    //Only the elements that will be interacted with
    CardView btnWeather, btnNews, btnTraffic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //We need to bind the java variable with the correct XML object
        btnWeather = findViewById(R.id.btnWeather);
        btnNews = findViewById(R.id.btnNews);
        btnTraffic = findViewById(R.id.btnTraffic);

        //When we click on the cards start the appropriate activity
        btnWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //To start an activity we need an intent. Also, to start an activty we have to launch it from another activity.
                Intent intent = new Intent(MainActivity.this,Weather.class);
                startActivity(intent);
            }
        });

        btnNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,News.class);
                startActivity(intent);
            }
        });

        btnTraffic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Traffic.class);
                startActivity(intent);
            }
        });

    }
}
