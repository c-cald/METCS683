package com.example.dashboard;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ArrayAdapter_Article extends ArrayAdapter<Article> {

    private Context mContext;
    private ArrayList<Article> listArticles = new ArrayList<>();

    public ArrayAdapter_Article(@NonNull Context context, ArrayList<Article> list) {
        super(context, 0 , list);
        mContext = context;
        listArticles = list;
    }


    //Get called when drawing a row
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(R.layout.custom_listview_article, parent, false);
        }

        TextView txtTitle = listItem.findViewById(R.id.txtTitle);
        TextView txtAuthor = listItem.findViewById(R.id.txtAuthor);
        TextView txtSource = listItem.findViewById(R.id.txtSource);
        ImageView image = listItem.findViewById(R.id.imageView);

        txtTitle.setText( listArticles.get(position).getTitle()  );
        txtAuthor.setText( listArticles.get(position).getAuthor()  );
        txtSource.setText( listArticles.get(position).getSource()  );

        //Use picasso library to load an image from a url into our image view
        String imageUrl =  listArticles.get(position).urlToImage;
        //imageUrl = "" is there is no image
        if ( imageUrl != null && !imageUrl.equals("") ){
            Picasso.get().load(imageUrl).into(image);
        }



        return listItem;
    }
}