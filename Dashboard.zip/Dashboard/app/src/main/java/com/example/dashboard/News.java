package com.example.dashboard;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class News extends AppCompatActivity {

    public static final String KEY_CONTENT = "CONTENT";
    public static final String API_KEY = "db5a06d505aa472fab39469f81cb3455";

    //Declare all XML elements as Java variables
    EditText edtSearch;
    Button btnSearch, btnBack;
    ListView lstNewsArticles;
    TextView txtNumResults, txtError;
    ArrayList<Article> articles = new ArrayList<>();
    String dateFormatted;
    Spinner spnSortBy;
    SharedPreferences pref;
    SharedPreferences.Editor editor;


    //API Reference
    //https://newsapi.org/v2/everything?q=bitcoin&from=2019-10-22&sortBy=publishedAt&apiKey=2bc5e274d9454534820d45ec7ad23c13

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        edtSearch = findViewById(R.id.edtSearch);
        btnSearch = findViewById(R.id.btnSearch);
        lstNewsArticles = findViewById(R.id.lstNewsArticles);
        txtNumResults = findViewById(R.id.txtNumResults);
        txtError = findViewById(R.id.txtError);
        spnSortBy = findViewById(R.id.spnSortBy);
        btnBack = findViewById(R.id.newsBtnBack);

        //The newsAPI will only return results if the 'from' parameter is less than 30 days before today
        //Get the current date and subtract 29 days, then format it to yyyy-MM-dd
        Calendar cal = Calendar.getInstance();
        // adding -1 month
        cal.add(Calendar.MONTH, -1);
        cal.add(Calendar.DATE, 1);
        Date currentTime = cal.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        dateFormatted = formatter.format(currentTime);

        //There is a dropdown spinner menu that lets the user select how they want the results to be ordered
        //We need a string array for the options
        final String spinnerItems[] = {"Date Published","Popularity","Relevancy"};
        //This array adapter will show the string array of options in the spinner
        ArrayAdapter<String> adpSpn = new ArrayAdapter<>(News.this,android.R.layout.simple_list_item_1,spinnerItems);
        //Bind the adapter to our spinner
        spnSortBy.setAdapter(adpSpn);

        //check shared preferences for a sort by value
        //if there is a value change the spinner accordingly
        //"custom" refers to the name of the file where the data is saved
        pref = getApplicationContext().getSharedPreferences("custom", 0); // 0 - for private mode
        //pref gives us access to the file with stored values and editor allows us to edit those values on the fly
        editor = pref.edit();
        //check that we found a "custom" file in our SharedPreferences
        if (pref != null){
            //Get the data that we saved. We decided the key below when we saved the data
            String sortBy = pref.getString("sortBy",null);
            //if we have a sortBy value
            if (sortBy != null){


                //In order to set the spinner programmatically we need to use the index of the option
                // we want to select

                //Iterates through the possibilities of our spinner item, if the items match then set the selection to be that index
                //lets say sortBy == "Popularity", cycle through Spinner Strings. When we find "Popularity" set the selected spinner
                //index to be the current index
                for (int i = 0; i < spinnerItems.length; i++){
                    if (spinnerItems[i].equals(sortBy)){
                        spnSortBy.setSelection(i);
                        break;
                    }
                }
            }
        }



        //After spinner has been populated search a default API, we search for USA
        GetFromApi getNewsData = new GetFromApi();
        getNewsData.execute("https://newsapi.org/v2/everything?q=USA&from=" + dateFormatted + "&sortBy=publishedAt&apiKey=" + API_KEY  );


        //Save the selected spinner item to shared preferences to be referenced the next time the app is open
        spnSortBy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                //position represents the index that was clicked on
                //spinnerItems = {"Date Published","Popularity","Relevancy"};
                String saveString = spinnerItems[position];
                //Save the selected item to sharedPreferences
                editor.putString("sortBy", saveString);
                editor.apply();

                //once the sortby has changed lets research the api

                    //if we are on the default page redo default search based on spinner
                    //if datepublished is selected reformat so the API will work
                    String sortBy = spinnerItems[spnSortBy.getSelectedItemPosition()];
                    if (sortBy.equals("Date Published")){
                        sortBy = "publishedAt";
                    }

                    if(edtSearch.getText().toString().length() == 0 ){
                         GetFromApi getNewsData = new GetFromApi();
                         getNewsData.execute("https://newsapi.org/v2/everything?q=USA&from=" + dateFormatted + "&sortBy=" + sortBy +"&apiKey=" + API_KEY   );
                    } else {

                        GetFromApi getNewsData = new GetFromApi();
                        getNewsData.execute("https://newsapi.org/v2/everything?q=" + edtSearch.getText().toString().trim() +"&from=" + dateFormatted +
                                "&sortBy=" + sortBy +"&apiKey=" + API_KEY  );
                    }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Before we search make sure that there is text in the search textview
                if(edtSearch.length() == 0){
                    edtSearch.requestFocus();
                    edtSearch.setError("Field cannot be empty");

                } else {
                    txtError.setVisibility(View.INVISIBLE);
                    //if there is data in the search bar
                    //Implement code to grab the value of the search bar and the value of the spinner and then search the news api

                    //if datepublished is selected reformat so the API will work
                    String sortBy = spinnerItems[spnSortBy.getSelectedItemPosition()];
                    if (sortBy.equals("Date Published")){
                        sortBy = "publishedAt";
                    }
                    //get data from the api
                    GetFromApi getNewsData = new GetFromApi();
                    getNewsData.execute("https://newsapi.org/v2/everything?q=" + edtSearch.getText().toString().trim() +"&from=" + dateFormatted +
                            "&sortBy=" + sortBy +"&apiKey=" + API_KEY  );
                }

            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //built into Android, this function ends/closes the current activity
                finish();
            }
        });


        //If we wanted to do something when we click on a row in the news listview
        /*lstNewsArticles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                //Start the content activity
                Intent intent = new Intent(MainActivity.this, Content.class);
                //Put the data we want to send in the intent as an extra
                intent.putExtra(KEY_CONTENT, articles.get(position).getContent()  );
                startActivity(intent);



            }
        });*/


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.navigation_news, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menu_weather:
                //start the weather activity
                Intent intent = new Intent(News.this,Weather.class);
                startActivity(intent);
                finish();
                return true;
            case R.id.menu_traffic:
                //start the traffic activity
                Intent intent3 = new Intent(News.this,Traffic.class);
                startActivity(intent3);
                finish();
                return true;
            case R.id.menu_exit:
                //exit the entire app
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    private class GetFromApi extends AsyncTask<String,Integer,String> {

        @Override
        protected void onPreExecute() {
            //Setup precondition to execute some task
            //may want to show a progress dialog

        }

        //.execute("url")
        //

        @Override
        protected String doInBackground(String... params) {
            //Do some task

            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            String result = null;
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                //HttpURLConnection.HTTP_
                //int responseCode = connection.getResponseCode();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line = "";
                    while (   (line = reader.readLine()   ) != null) {
                        stringBuilder.append(line);
                    }
                    result = stringBuilder.toString();
                }
            } catch (Exception e) {
                //Handle the exceptions
                Log.d("Error", "cant get data from internet");
                //showMsg("Error: cant get data from the internet: " + e.getMessage());

            } finally {
                //Close open connections and reader
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        showMsg("Error closing reader");
                    }
                }
            }
            return result;
            //publishProgress (1);

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //Update the progress of current task
        }

        @Override
        protected void onPostExecute(String result) {
            //Show the result obtained from doInBackground

            //Keys below are based on the API, we figured this out by pasting in a test API to Google Chrome
            //https://newsapi.org/v2/everything?q=trees&from=2019-10-22&sortBy=publishedAt&apiKey=db5a06d505aa472fab39469f81cb3455
            //if there is no result the app will crash

            if (result != null) {

                try {
                    JSONObject jsonResult = new JSONObject(result);

                    //extract number of results and display on our activity
                    int numResults = jsonResult.getInt("totalResults");
                    txtNumResults.setText(Integer.toString(numResults));

                    if (numResults == 0){
                        //clear current results
                        articles.clear();
                        //Add to the listview that there are no results
                        String temp[] = {"No results for this search term"};
                        ArrayAdapter<String> adpNoResults = new ArrayAdapter<>(News.this,android.R.layout.simple_list_item_1, temp);
                        lstNewsArticles.setAdapter(adpNoResults);

                    } else {

                        //The articles are return as a json array
                        JSONArray jsonArticles = jsonResult.getJSONArray("articles");

                        //Clear the current list of articles in case we have already searched for something else
                        articles.clear();
                        //iterate through all articles. Articles are JSONObjects
                        for (int i = 0; i < jsonArticles.length(); i++) {
                            JSONObject curNewsArticle = jsonArticles.getJSONObject(i);
                            //Extract the data for the current Article
                            String name = curNewsArticle.getJSONObject("source").getString("name");
                            String title = curNewsArticle.getString("title");
                            String author = curNewsArticle.getString("author");
                            String content = curNewsArticle.getString("content");
                            String url = curNewsArticle.getString("url");
                            String urlToImage = curNewsArticle.getString("urlToImage");
                            //create new article object and create a local copy to be save in our app in the ArrayList articles
                            Article temp = new Article(author, title, content, name, url, urlToImage);
                            articles.add(temp);
                        }

                        //In order to populate a listview you need 3 things
                        //1. Data to show
                        //2. Array Adapter which tells android what data to put where
                        //3. Listview
                        //This is a custom array adapter that can take in a list of Article objects
                        ArrayAdapter_Article adpArticles = new ArrayAdapter_Article(News.this, articles);
                        lstNewsArticles.setAdapter(adpArticles);

                    }//ends the else for if 0 results

                } catch(JSONException e){
                    e.printStackTrace();
                }

            } else {
                Toast.makeText(News.this, "API parameters did not return any data", Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void showMsg(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
